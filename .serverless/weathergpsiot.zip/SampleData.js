
//moab, ut  

[
	{
	   "uptime": 100,
	   "intemp": 77,
	   "inhumid": 66,
	   "lat": 38.5743966,
	   "long": -109.5689282

	}
]

//tuscon, az

[
	{
	   "uptime": 110,
	   "intemp": 88,
	   "inhumid": 99,
	   "lat": 32.1558328,
	   "long": -111.0238918
	}
]

//chicago

[
	{
	   "uptime": 120,
	   "intemp": 85,
	   "inhumid": 95,
	   "lat": 41.881832,
	   "long": -87.623177
	}
]


//stevenson

[
	{
	   "uptime": 120,
	   "intemp": 88,
	   "inhumid": 99,
	   "lat": 45.6944496,
	   "long": -121.9115935
	}
]